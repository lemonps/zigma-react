const userInfoList = artifacts.require('./userInfoList.sol')

contract('userInfoList', (accounts) => {
  before(async () => {
    this.userInfoList = await userInfoList.deployed()
  })

  it('deploys successfully', async () => {
    const address = await this.userInfoList.address
    assert.notEqual(address, 0x0)
    assert.notEqual(address, '')
    assert.notEqual(address, null)
    assert.notEqual(address, undefined)
  })

  it('lists users', async () => {
    const userCount = await this.userInfoList.userCount()
    const user = await this.userInfoList.users(userCount)
    assert.equal(user.id.toNumber(), userCount.toNumber())
    assert.equal(user.firstName, 'satid')
    // assert.equal(user.completed, false)
    assert.equal(userCount.toNumber(), 1)
  })

  it('creates users', async () => {
    const result = await this.userInfoList.createUser('newUser', 'newUser2')
    const userCount = await this.userInfoList.userCount()
    assert.equal(userCount, 2)
    const event = result.logs[0].args
    assert.equal(event.id.toNumber(), 2)
    assert.equal(event.firstName, 'newUser')
    assert.equal(event.lastName, 'newUser2')
    // assert.equal(event.completed, false)
  })

  // it('toggles task completion', async () => {
  //   const result = await this.userInfoList.toggleCompleted(1)
  //   const task = await this.userInfoList.tasks(1)
  //   assert.equal(task.completed, true)
  //   const event = result.logs[0].args
  //   assert.equal(event.id.toNumber(), 1)
  //   assert.equal(event.completed, true)
  // })

})
