var userInfoList = artifacts.require("./userInfoList.sol");

module.exports = function(deployer) {
  deployer.deploy(userInfoList);
};
